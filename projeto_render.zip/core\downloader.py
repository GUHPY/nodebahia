import yt_dlp
import requests
import os
import platform

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
COOKIE_FILE = os.path.join(BASE_DIR, "cookies", "instagram_cookie.txt")
FFMPEG_LOC = './ffmpeg.exe' if platform.system() == 'Windows' else 'ffmpeg'

def gerar_nome_unico(base_nome, extensao="mp4"):
    """
    Verifica se o arquivo já existe e adiciona um sufixo numérico para evitar sobrescrita.
    Ex: usuario.mp4 -> usuario_1.mp4 -> usuario_2.mp4
    """
    contador = 1
    nome_final = f"downloads/{base_nome}.{extensao}"
    
    while os.path.exists(nome_final):
        nome_final = f"downloads/{base_nome}_{contador}.{extensao}"
        contador += 1
        
    return nome_final

def baixar_via_api_tikwm(url):
    """
    PLANO B: Usa a API TikWM para extrair o vídeo sem marca d'água.
    """
    print("[!] yt-dlp falhou. Acionando Fallback via API TikWM...")
    api_url = "https://www.tikwm.com/api/"
    
    try:
        # Faz a requisição para a API passando o link do vídeo
        resposta = requests.get(api_url, params={"url": url})
        dados = resposta.json()
        
        if dados.get("code") == 0:
            nome_criador = dados["data"]["author"]["unique_id"]
            link_video = dados["data"]["play"]
            
            # API Fallback vai sempre para "downloads_avulso" para não travar lotes, ou para main folder
            nome_arquivo = f"downloads/{nome_criador}_fallback.mp4"
            
            video_bytes = requests.get(link_video).content
            
            with open(nome_arquivo, 'wb') as f:
                f.write(video_bytes)
                
            return True
        else:
            return False
            
    except Exception as e:
        return False

def baixar_video(url, batch_path="downloads", progress_queue=None):
    """
    PLANO A: Tenta usar o yt-dlp primeiro.
    Se falhar, aciona a função baixar_via_api_tikwm automaticamente.
    """
    url_limpa = url.split('?')[0]

    with yt_dlp.YoutubeDL({'quiet': True}) as ydl:
        info = ydl.extract_info(url_limpa, download=False)
        usuario = info.get('uploader', 'usuario_desconhecido')

    caminho_final = os.path.join(batch_path, f"{usuario}.mp4")
    
    # Adicionamos um sufixo numerico manual caso aja arquivo repetido no lote
    contador = 1
    while os.path.exists(caminho_final):
        caminho_final = os.path.join(batch_path, f"{usuario}_{contador}.mp4")
        contador += 1
        
    def hook_progresso(d):
        if d['status'] == 'downloading':
            if progress_queue:
                progress_queue.put({
                    "status": "progress",
                    "percent": d.get('_percent_str', '0%').strip(),
                    "speed": d.get('_speed_str', ''),
                    "eta": d.get('_eta_str', '')
                })
        elif d['status'] == 'finished':
            if progress_queue:
                progress_queue.put({"status": "info", "message": "Download concluído, processando FFmpeg..."})

    opcoes_yt_dlp = {
        # O outtmpl agora usa o caminho exato que calculamos
        'outtmpl': caminho_final,
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'quiet': False,
        'no_warnings': False,
        'ffmpeg_location': FFMPEG_LOC,
        'postprocessor_args': [
            '-c:v', 'libx264',
            '-profile:v', 'high',
            '-pix_fmt', 'yuv420p',
            '-c:a', 'aac',
            '-b:a', '128k',
        ],
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        },
        'progress_hooks': [hook_progresso],
    }

    try:
        print(f"[*] Tentando yt-dlp para: {url}")
        with yt_dlp.YoutubeDL(opcoes_yt_dlp) as ydl:
            ydl.download([url_limpa])
        print("[+] Sucesso via yt-dlp!\n")
        return True
    
    except Exception as e:
        print(f"\n[!] DIAGNÓSTICO DE ERRO DO YT-DLP:")
        # O repr(e) força o Python a mostrar o erro em formato bruto
        print(f"Motivo da falha: {repr(e)}\n")
        
        return baixar_via_api_tikwm(url)
    
def baixar_video_instagram(url, batch_path="downloads", progress_queue=None):
    """
    Motor dedicado para o Instagram. Usa os cookies para burlar o bloqueio de login.
    """
    if progress_queue:
        progress_queue.put({"status": "info", "message": f"Injetando cookies Instagram para: {url}"})
    
    url_limpa = url.split('?')[0]

    opcoes_extracao = {
        'quiet': True, 
        'cookiefile': COOKIE_FILE
    }
    
    with yt_dlp.YoutubeDL(opcoes_extracao) as ydl:
        try:
            info = ydl.extract_info(url_limpa, download=False)
            usuario = info.get('uploader', 'insta_user')
        except Exception:
            usuario = 'insta_user'

    caminho_final = os.path.join(batch_path, f"{usuario}.mp4")
    
    # Adicionamos um sufixo numerico manual caso aja arquivo repetido no lote
    contador = 1
    while os.path.exists(caminho_final):
        caminho_final = os.path.join(batch_path, f"{usuario}_{contador}.mp4")
        contador += 1
        
    def hook_progresso(d):
        if d['status'] == 'downloading':
            if progress_queue:
                progress_queue.put({
                    "status": "progress",
                    "percent": d.get('_percent_str', '0%').strip(),
                    "speed": d.get('_speed_str', ''),
                    "eta": d.get('_eta_str', '')
                })
        elif d['status'] == 'finished':
            if progress_queue:
                progress_queue.put({"status": "info", "message": "Download concluído, processando FFmpeg Instagram..."})

    opcoes_yt_dlp = {
        'outtmpl': caminho_final,
        'format': 'bestvideo[ext=mp4]+bestaudio[ext=m4a]/best[ext=mp4]/best',
        'quiet': False,
        'no_warnings': False,
        
        # A CHAVE MESTRA: Isso diz ao yt-dlp para fingir que é a sua conta logada
        'cookiefile': COOKIE_FILE, 
        
        # Aponta diretamente para o FFmpeg (local no Windows, ou global no Hostgator Linux)
        'ffmpeg_location': FFMPEG_LOC,
        
        'postprocessor_args': [
            '-c:v', 'libx264',
            '-profile:v', 'high',
            '-pix_fmt', 'yuv420p',
            '-c:a', 'aac',
            '-b:a', '128k',
        ],
        
        'http_headers': {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        },
        'progress_hooks': [hook_progresso],
    }

    try:
        print(f"[*] Iniciando download seguro via yt-dlp (Instagram)...")
        with yt_dlp.YoutubeDL(opcoes_yt_dlp) as ydl:
            ydl.download([url_limpa])
        print(f"[+] Sucesso! Vídeo do Instagram salvo em: {caminho_final}\n")
        return True
    
    except Exception as e:
        print(f"\n[!] FALHA NO INSTAGRAM:")
        print(f"Motivo: {repr(e)}")
        print("[DICA] Verifique se o instagram_cookie.txt está válido ou se a conta foi deslogada.\n")
        return False