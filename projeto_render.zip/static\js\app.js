document.addEventListener('DOMContentLoaded', () => {
    // === ELEMENTOS DA UI ===
    const linksTextarea = document.getElementById('links-textarea');
    const syncStatus = document.getElementById('sync-status');
    const btnDownload = document.getElementById('btn-download');

    const consoleLogs = document.getElementById('console-logs');
    const progressContainer = document.getElementById('progress-container');
    const progressFill = document.getElementById('progress-fill');
    const progressPercentage = document.getElementById('progress-percentage');
    const progressText = document.getElementById('progress-text');
    const progressDetail = document.getElementById('progress-detail');

    const btnCookies = document.getElementById('btn-cookies');
    const cookieModal = document.getElementById('cookie-modal');
    const btnCloseCookie = document.getElementById('btn-close-cookie');
    const btnSaveCookie = document.getElementById('btn-save-cookie');
    const cookieTextarea = document.getElementById('cookie-textarea');

    let isDownloading = false;

    // === INICIALIZAÇÃO ===
    // 1. Carregar Links
    fetch('/api/links')
        .then(res => res.json())
        .then(data => {
            linksTextarea.value = data.content;
        });

    // 2. Carregar Cookies
    fetch('/api/cookies')
        .then(res => res.json())
        .then(data => {
            cookieTextarea.value = data.content;
        });

    // === ROTINAS EDITOR DE LINKS (AUTOSAVE) ===
    let debounceTimer;
    linksTextarea.addEventListener('input', () => {
        syncStatus.textContent = "Salvando...";
        syncStatus.className = "status-badge syncing";

        clearTimeout(debounceTimer);
        debounceTimer = setTimeout(() => {
            salvarLinks(linksTextarea.value);
        }, 800);
    });

    function salvarLinks(conteudo) {
        fetch('/api/links', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: conteudo })
        }).then(res => res.json())
            .then(() => {
                syncStatus.textContent = "Sincronizado";
                syncStatus.className = "status-badge";
            });
    }

    // === ROTINAS MODAL DE COOKIES ===
    btnCookies.addEventListener('click', () => cookieModal.classList.add('active'));
    btnCloseCookie.addEventListener('click', () => cookieModal.classList.remove('active'));

    // Fechar ao clicar fora do modal
    cookieModal.addEventListener('click', (e) => {
        if (e.target === cookieModal) cookieModal.classList.remove('active');
    });

    btnSaveCookie.addEventListener('click', () => {
        btnSaveCookie.textContent = "Salvando...";
        fetch('/api/cookies', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ content: cookieTextarea.value })
        }).then(res => res.json())
            .then(() => {
                btnSaveCookie.innerHTML = "<i class='fa-solid fa-check'></i> Salvo";
                setTimeout(() => {
                    btnSaveCookie.textContent = "Salvar Cookies";
                    cookieModal.classList.remove('active');
                }, 1000);
            });
    });

    // === SISTEMA DE LOGS ===
    function log(message, type = 'info') {
        const div = document.createElement('div');
        div.className = `log-line ${type}`;
        div.textContent = `[${new Date().toLocaleTimeString()}] ${message}`;
        consoleLogs.appendChild(div);
        consoleLogs.scrollTop = consoleLogs.scrollHeight;
    }

    // === ROTINA DE DOWNLOAD (SSE) ===
    btnDownload.addEventListener('click', () => {
        if (isDownloading) return;

        // Verifica se há links
        if (!linksTextarea.value.trim()) {
            log('A caixa de links está vazia. Adicione links antes de baixar.', 'warning');
            return;
        }

        iniciarInterfaceDownload();

        fetch('/api/download', { method: 'POST' })
            .then(res => res.json())
            .then(data => {
                if (data.status === 'started') {
                    escutarProgresso();
                }
            });
    });

    function iniciarInterfaceDownload() {
        isDownloading = true;
        btnDownload.disabled = true;
        btnDownload.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Processando...';
        progressContainer.style.display = 'block';

        // Reset Progress
        progressFill.style.width = '0%';
        progressPercentage.textContent = '0%';
        progressText.textContent = 'Iniciando Lote...';
        progressDetail.textContent = 'Aguardando backend...';
        consoleLogs.innerHTML = '';
        log('Iniciando comunicação com o motor de download...', 'info');
    }

    function finalizarInterfaceDownload() {
        isDownloading = false;
        btnDownload.disabled = false;
        btnDownload.innerHTML = '<i class="fa-solid fa-rocket"></i> Iniciar Download em Lote';

        // Se a barra travou no meio, reseta a aparência discretamente depois de um tempo
        setTimeout(() => {
            progressContainer.style.display = 'none';
        }, 5000);
    }

    function escutarProgresso() {
        const evtSource = new EventSource('/stream');

        evtSource.onmessage = function (event) {
            const data = JSON.parse(event.data);

            if (data.status === 'connected') {
                log('Conectado ao canal de dados ao vivo.', 'success');
                return;
            }

            if (data.status === 'done') {
                log('Workflow de lote finalizado.', 'success');
                finalizarInterfaceDownload();
                evtSource.close();
                return;
            }

            if (data.status === 'info') {
                log(data.message, 'info');
                progressDetail.textContent = data.message;
            }

            if (data.status === 'progress') {
                // Ao mapearmos de link em link
                if (data.video_index) {
                    const currentPercent = ((data.video_index - 1) / data.total) * 100;
                    progressFill.style.width = `${currentPercent}%`;
                    progressPercentage.textContent = `${Math.round(currentPercent)}%`;
                    progressText.textContent = `Vídeo ${data.video_index} de ${data.total}`;
                }

                // Progresso super-fino do YT-DLP vindo do backend
                if (data.percent) {
                    // Limpar códigos ANSI que o yt-dlp pode retornar
                    const cleanPercent = data.percent.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '').trim();
                    const cleanEta = data.eta ? data.eta.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '').trim() : '';

                    progressFill.style.width = cleanPercent;

                    // Exibir e.g. "50% (40s)"
                    const displayPercent = cleanPercent.replace('%', '');
                    progressPercentage.textContent = `${displayPercent}% ${cleanEta ? `(${cleanEta})` : ''}`;

                    const cleanSpeed = data.speed ? data.speed.replace(/\x1b\[[0-9;]*[a-zA-Z]/g, '').trim() : '';
                    progressDetail.textContent = cleanSpeed;
                }

                if (data.message) {
                    log(data.message, 'progress');
                }
            }

            if (data.status === 'success') {
                log(data.message, 'success');
                progressFill.style.width = `100%`;
                progressPercentage.textContent = `100%`;
                progressText.textContent = `Concluído!`;
                progressDetail.textContent = `Todos os vídeos salvos.`;
            }

            if (data.status === 'warning') {
                log(data.message, 'warning');
            }

            if (data.status === 'error') {
                log(data.message, 'error');
                progressText.textContent = 'Erro detectado';
            }
        };

        evtSource.onerror = function (err) {
            log('Conexão perdida com o motor de progresso.', 'error');
            evtSource.close();
            finalizarInterfaceDownload();
        };
    }
});
